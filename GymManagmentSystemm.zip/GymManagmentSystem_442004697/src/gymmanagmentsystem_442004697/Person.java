/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gymmanagmentsystem_442004697;
/**
 * abstract class Person implements interface Editor
 * this abstract class have the common and standard information to used for the member or for the trainer
 * All information is private and confidential and have the method which provide the functionality and it deal with the data
 * this information used to handle with the process of storing member or trainer and to  be able to edit the list of people we will make it from them
 * @author Esra saif
 * @version 1
 * 
 */

//import bulid in classes

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.lang.NumberFormatException ;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public abstract class Person implements Editor {
    
    //fields
    
    
   /**
    * numberPhone private instance attribute belong to member or trainer object , represent the numberphone 
    */
    protected String numberPhone ;
   
   /**
    * name private instance attribute belong to member or trainer object , represent the name of member or trainer object
    */
   protected String name ;
   
   
    /**
    * name private instance attribute belong to member or trainer object , represent the email address of member or trainer object
    */
    protected String email;
   
    /**
    * id protected instance attribute belong to member or trainer object , represent the id of member or trainer object
    *  we can access to the person which can be for member or trainer throw its id 
    */
   protected long id;
   
   
    /**
    * listPepole protected instance attribute belong to member or trainer object , represent the list of members or trainers 
    *  it represent the members and trainers that we have in our gym 
    */
   protected ArrayList<String> listPepole;
     
   
   //methods
   
   /**
    * Person is default constrctor
    */
   Person()
   {
   }
   
  
    /**
    * Person is parametrized constrctor which initilaize the name and the id of the person
    */
    Person(String name ,long UserId)
    {
    
      this.name =name ;
      this.id=UserId;
    
    }
    
    
    /**
    * getNumberPhone instance method that return the numberPhone
    * @return numberPhone of the person
    */
    public String getNumberPhone() {
        return numberPhone;
    }

    /**
    * setNumberPhone instance method that set the interd NumberPhone from the user 
    * this method recive numberPhone of person which may be member object or trainer object and it convert the String numberPhone to Long to know if it consist only digits or not 
    * if it consist other than digits from 0 to 9 it will cause an exception of type NumberFormatException so i put the message that will apper when the exception occourd 
    * here i decleared the exception by using throw keyowrd and put the name of possible exceptions that may be occourd by using throws  keyowrd tha handling with this  possible exception will be in the main by using try-catch blocks
    * @param numberPhone  numberphone of the person
    * @throws InputMismatchException, NumberFormatException 
    */
    public void setNumberPhone(String numberPhone)throws NumberFormatException , InputMismatchException //argument which will send to this method may cause this  exceptions
    {
        
        Long testvariable =  Long.parseLong(numberPhone);
        
        if(numberPhone.matches("\\d{10}"))  //this method will see if the enterd number mathces the regular format of number which i create it \\d{10} this character mean it allowed to inter numbers consist only digits from 0 to 9 and it must be with 10 digits not more or less than it 
             this.numberPhone =numberPhone;
        else
             throw new NumberFormatException("invalid number , please enter numberPhone with  10 digits without any characters and only consist digits from 0 to 9  ");

    }

    
    /**
    * getName instance method that return the name of person 
    * @return String name 
    */
    public String getName() {
        return name;
    }

    
    
    /**
    * setName instance method that set the interd name from the user 
    * this method recive name of person which may be member object or trainer object 
    * it will using loop to throw over the indices of  name to check if any of indices have other than letters then will cause an exciption of type NumberFormatException else than this will mean there is no character in each index of the string have other than letters and then the interd name will saved in the private attribute (name)
    * here i decleared the exception by using throw keyowrd and put the name of possible exceptions that may be occourd by using throws  keyowrd,  the handling with this  possible exception will be in the main by using try-catch blocks
    * @param name  , name of the person
    * @throws InputMismatchException , NumberFormatException
    *
    */
    public void setName(String name)throws InputMismatchException , NumberFormatException //argument which will send to this method may cause an exception
    {
        loop:for(int i = 0 ; i <name.length() ; i++)
         {  
             switch(name.charAt(i))
             {
                case '0':
                case '1':    
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    this.name="";
                  throw new NumberFormatException("invalid name , you have to insert only alphapet letters");
     
                 default:
                          this.name = name;
  
           
           }
                         
         }
             
 
    }
    
     /**
    *  getEmail instance method that return the email address  of person 
    * @return String email 
    */
    public String getEmail() {
        return email;
    }

    
    
    /**
    * setEmail instance method that set the interd email from the user 
    * by using class Pattern  i made object from it and recive the format  of the correct email adress whitch i want from user to insert like it throw method compile the sympols in the string will understood 
    * then by using matcher method from Pattren object and pass to it the string that the user interd will match it with the pattren whitch i make it and the value will set in Matcher object 
    * by using method matches we will no if the inters email match the correct format of email witch i selected or not if it correct then the interd email will put in attribute email which belong to mamber object or trainer object otherwise wil cause an exception 
    * here i decleared the exception by using throw keyowrd and put the name of possible exceptions that may be occourd by using throws  keyowrd ,, the handling with this  possible exception will be in the main by using try-catch blocks
    * @param email  , set the email of the person
    * @throws InputMismatchException, NumberFormatException 
    */
    
    
    public void setEmail(String email)throws InputMismatchException, NumberFormatException    //argument which will send to this method may cause an exception
    {  
                 
          //this string which i send it to compile method  represent which parts of emaill allowed in the emaill i mean it possible to found it in the email from user 
            Pattern p = Pattern.compile("^[\\w-]{1,20}@\\w{2,10}\\.\\w{2,3}$"); //object from class called Pattern that i put the correct format witch have to insert from user
            
            Matcher m = p.matcher(email);    //object from class Matcher witch throw its method mather resposible to validate if the string valid to the basic format that i restrected or not
                                           //this method will return true if the string matches the basic format of email which i sellected
            
                                           //"[\\w-]{1,20}@\\w{2,10}\\.\\w{2,3}$"
                                           //" ^ [A-Za-z0-9_-]+[@](hotmail|gmail|yahoo)\\.\\w{3} $ "
            if( m.matches() ==true)
            this.email = email;
            else
               throw new NumberFormatException("invalid email , you have to insert  correect format of email like , ");
           
    }

    
    /**
    *  getEmail instance method that return the email address  of person 
    * @return String email 
    */
    public long getId() {
        return id;
    }
    
    /**
    * setId instance method that insert the id of each object wecreated from member class or trainer class
    * the value of id will created in the main class and the programmer will send it throw this method to set the id of each new member or trainer
    * @param  id of the person
    */
    public void setId(long id) {
        this.id = id;
    }

    
    
   //method receive the position and the name of person to add it in the list
   @Override
    public void add(int index , String objName)  //editing it from uml
    {
        listPepole.add(index, objName);
    }
  
    
    //method receive the position of person to remove it from the list
   @Override
    public  void  delete(int index)
    {
       listPepole.remove(index);
    }
    
    
    //method return the list of pepole
   @Override
    public   ArrayList<String> getList()
    {   
      return listPepole;
    }
    
    
    //method receive object of type String whitch represent the name of person to search about its position in the list
   @Override
    public  int  search(String obj)
    {
      return listPepole.indexOf(obj);
    }
    
    
   /**
      *  toString abstract method represent information about objects 
      * @return string 
      */
   @Override
    public abstract  String toString();//abstract method which override it in the subclass according to its information that we want to represent it
    
    
    
     /**
      * equals abstract method will test  the id between two objects 
      * @param o it is  object of type Object class ,  it will casting recive object to member object or trainer object 
      * @return true or false according to the comparing between the attributes
      */
    
   @Override
   public abstract boolean equals(Object o);
  
  
    
}


//  //support method which test if the inserted number correct or not
//   private boolean isValidNumber(String num)
//   {
//     if(num.length()==10)
//     {  if(!(num.contains("0")|num.contains("1")|num.contains("2")|num.contains("3")|num.contains("4")|num.contains("5")|num.contains("6")|num.contains("7")|num.contains("8")|num.contains("9")))
//        return true;
//     
//         else
//          return false ;
//   
//     }
//      else
//          return false ;
//   
//   
//   }
//   
//   
    
    //ط·ط±ظٹظ‚ط© ط§ط®ط±ظ‰  ظ„ظ„طھط£ظƒط¯ ظ…ظ† ط§ظ† ط§ظ„ط±ظ‚ظ… طµط­ظٹط­
    // check1: if(numberPhone.length()==10)
//        {
//            for(int i = 0 ; i <numberPhone.length() ; i++)
//               switch(numberPhone.charAt(i))
//             {
//                 case '0':
//                 case '1':    
//                 case '2':
//                 case '3':
//                 case '4':
//                 case '5':
//                 case '6':
//                 case '7':
//                 case '8':
//                 case '9':
//                           
//                
//                default:
//                        System.out.println("invalid number , please enter numberPhone with length of 10 and only consist digits from 0 to 9  ");
//                        break check1;             
//             }//end switch
//         this.numberPhone = numberPhone;
//         
//        }//end if block
//            else
//           {
//               System.out.println("invalid number , please enter numberPhone with length of 10 and only consist digits from 0 to 9  ");
//                  return;
//           }
//

