/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gymmanagmentsystem_442004697;

/**
 *
 * @author maramkhouj
 */
public class Diets {
    
    // attributes
    
    private String dietName;
    private String dietType;
    private String dietDescription;
    
    //constructors
    
    Diets(){}
    
    Diets(String name, String type, String description ){
        dietName=name;
        dietType=type;
        dietDescription=description;
    }
    
    //setters
    
    public void setDietName(String name){dietName=name;}
    public void setDietType(String type){dietType=type;}
    public void setDietDescription(String description){dietDescription=description;}
    
    //getters
    
    public String getDietName(){return dietName;}
    public String getDietType(){return dietType;}
    public String getDietDescription(){return dietDescription;}
    
    //other methods
    
    @Override
    public String toString(){return dietName+" consider as a form of "+dietType+",\nHow it works: "+dietDescription;}
}


