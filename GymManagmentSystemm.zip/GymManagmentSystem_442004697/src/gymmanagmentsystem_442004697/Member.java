/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gymmanagmentsystem_442004697;

/**
 *
 * @author Ahlam
 */

import java.util.Date;
import java.util.GregorianCalendar;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * concrete class Member extends abstract Person
 * To create an Object of member class type
 * it Save member information the healthStatus, subscriptionType, weight,length, and age
 * @author Ahlam
 */
public class Member extends Person {

    //instant fields
    
    /**MYPACKAGES This attribute object from class Packages
    */
    private  Packages myPackages;
    
    /**HEALTHSTATUS This attribute holds the healthStatus of the member  
    */
    //HEALTHSTATUS is an instant constant that belongs to an object
    //its value will differ from one object to another
    private String healthStatus;
    
    /**SUBSCRIPTIONTYPE This attribute holds the subscription type selected by the member  
    */
    //SUBSCRIPTIONTYPE is an instant constant that belongs to an object
    //its value will differ from one object to another
    private String subscriptionType;
    
    /**WEIGHT This attribute holds the weight of the member  
    */
    //WEIGHT is an instant constant that belongs to an object
    //its value will differ from one object to another
    private double weight; 
    
    /**LENGTH This attribute holds the length of the member  
    */
    //LENGTH is an instant constant that belongs to an object
    //its value will differ from one object to another
    private double length;
    
    /**AGE This attribute holds the age of the member  
    */
    //AGE is an instant constant that belongs to an object
    //its value will differ from one object to another
    private int age;
    
    private static long counter=0;

    //methods
    
    //constructor 
    public Member()
    { 
    }
    
 
    public Member(String healthStatus, String subscriptionType, double weight, double length, int age)
    {
        this.healthStatus = healthStatus;
        this.subscriptionType = subscriptionType;
        this.weight = weight;
        this.length = length;
        this.length = age;
    }
    // the following statements are examples of  objects of member class
	//creating object named mb
        //Member mb = new Member( good, goldon package,60, 160, 18))
        //mb.healthStatus ->good
        //mb.subscriptionType ->goldon package
        //mb.weight ->60
        //mb.length ->160
        //mb.age->18
    //

    public Member(String name, long id) {
        super(name, counter++);
       
    }
    
    public Packages getMyPackages()
    {
        return myPackages;
    }

    public void setMyPackages(Packages myPackages) {
        this.myPackages = myPackages;
    }
  
    /**
     * getHealthStatus returns the health Status of the member
     * @return HEALTHSTATUS health Status
     */
    public String getHealthStatus() 
    {
        return healthStatus;
    }
    
    /**
     * setHealthStatus changes the Health Status to a new Status
     * @param healthStatus as the new healthStatus
     */
    public void setHealthStatus(String healthStatus) 
    { 
        
       for(int i=0;i<healthStatus.length();i++)
        {
           
           char ch = healthStatus.charAt(i);
           if ((ch >= 'A' && ch <= 'Z')&& (ch >= 'a' && ch <= 'z'))
           {
               this.healthStatus=healthStatus;  
           } 

        }//end for
       
       if(this.healthStatus==null)
       {
       System.out.println("Please enter the healthStatus correctly");
       }
           
    }//end method
     
    
    /**
     * GETSUBSCRIPTIONTYPE returns the subscription type selected by the member
     * @return SUBSCRIPTIONTYPE subscription type
     */
    public String getSubscriptionType() 
    {
        return subscriptionType;
    }
    
    /**
     * setSubscriptionType changes the Subscription Type to a new Type
     * @param subscriptionType as the new Type
     */
    public void setSubscriptionType(int sub_type) 
    {
        if (sub_type==1)
        {
          this.subscriptionType = "golden package"; 
        }
        if (sub_type==2) 
        {
           this.subscriptionType = "silver package"; 
        }
        if (sub_type==3) 
        { 
          this.subscriptionType = "bronze package";   
        }
        else {System.out.println("This package is not available");}  
    }
    
    /**
     * GETWEIGHT returns the weight of the member
     * @return WEIGHT weight
     */
    public double getWeight()
    {
        return weight;
    }
    
    /**
     * setWeight changes the Weight to a new Weight
     * @param weight as the new Weight
     */
    public void setWeight(double weight)
    {
        if (weight>0) 
        {
        this.weight = weight;   
        }
        else System.out.println("Please enter the weight correctly");
    }

    /**
     * GETLENGTH returns the length of the member
     * @return LENGTH length
     */
    public double getLength()
    {
        return length;
    }
    
    /**
     * setLength changes the Length to a new Length
     * @param length as the new Length
     */
    public void setLength(double length)
    {
         if (length>0) 
         {
        this.length = length; 
        }
        else System.out.println("Please enter the length correctly");
    }
    
    /**
     * GETAGE returns the age of the member
     * @return AGE age
     */
    public int getAge()
    {
        return age;
    }
    
    /**
     * setAge changes the age to a new age
     * @param age as the new age
     */
    public void setAge(int age)
    {
         if (age>=18&& age<=60) 
         {
        this.age = age;  
        }
        else System.out.println("Age must be between 18 to 60");  
    }
    
    /**
     * subscriptionEnddate Shows the member the start date of the subscription and the date of the end of the subscription
     */
    
    // I used the Date,SimpleDateFormat and GregorianCalendar classes from outside the slides 
    
    public void subscriptionEnddate()
    { 
     Date date =new Date();//Object of Date class
     SimpleDateFormat dat = new SimpleDateFormat("dd/MM/yyyy");
    
     if(this.subscriptionType.equalsIgnoreCase("golden package"))
     {
     System.out.println("You have successfully subscribed to the golden package date: "+dat.format(date));//display subscription start date
     
     GregorianCalendar En = new GregorianCalendar();//GregorianCalendar Add the number of months
     En.add(GregorianCalendar.DATE,360);//12 month
     Date En2 = En.getTime();//transfer from GregorianCalendar to Date
     DateFormat D1 = DateFormat.getDateInstance();
     String E =D1.format(En2);//
     
     System.out.println("Subscription ends date:"+E);
     }
     
     if(this.subscriptionType.equalsIgnoreCase("silver package"))
     {
     System.out.println("You have successfully subscribed to the silver package date: "+dat.format(date));//display subscription start date
    
     GregorianCalendar En = new GregorianCalendar();//GregorianCalendar Add the number of months
     En.add(GregorianCalendar.DATE,180);//6 month
     Date En2 = En.getTime();//transfer from GregorianCalendar to Date
     DateFormat D1 = DateFormat.getDateInstance();
     String E =D1.format(En2);//
     
     System.out.println("Subscription ends date:"+E);
     }
     
     if(this.subscriptionType.equalsIgnoreCase("bronze package"))
     {
     System.out.println("You have successfully subscribed to the bronze package date: "+dat.format(date));//display subscription start date
     
     GregorianCalendar En = new GregorianCalendar();//GregorianCalendar Add the number of months
     En.add(GregorianCalendar.DATE,90);//3month
     Date En2 = En.getTime();//transfer from GregorianCalendar to Date
     DateFormat D1 = DateFormat.getDateInstance(); 
     String E =D1.format(En2);//
     
     System.out.println("Subscription ends date:"+E);
     
     }
     
    }
     public boolean equals (Object o){
         Member M = (Member)o;
        if(this.id ==(M.id)){
            return true;
        }
        else 
            return false;
         
     }
    public String toString(){
        return"health Status: "+this.healthStatus+",subscription Type: "+this.subscriptionType+", weight: "
           +this.weight+", length: "+this.length+", age: "+this.age+",number Phone: "+super.getNumberPhone()+",name: "+super.getName()+
             ", email: "+super.getEmail()+", id: "+super.getId();
    }
         
                
}

