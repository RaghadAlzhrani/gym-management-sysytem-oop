/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gymmanagmentsystem_442004697;
//import bulid in classes
import java.util.ArrayList;


/**
 * concrete class Packages 
 * To create an Object of Packages class type
 * it save Packages information the listWorkout, namePackage, durationPackage, pricePackage, typeDiet
 * @author rafaa alowaybidi
 * @version 1
 */
public class Packages {
    //attributes
    
    /**
     * workout private instance attribute hold object from class Workouts
     */
    private ArrayList<Workouts> listWorkout; 
    
    /**
     * namePackage private instance attribute holds name of package
     */
    private String namePackage;
    
    /**
     * durationPackage private instance attribute holds duration of package
     */
    private int durationPackage; 
    
    /**
     * pricePackage private instance attribute holds price of package
     */
    private double pricePackage; 
    
    /**
     * typeDiet private instance attribute holdsobject from class Dites
     */
    private Diets typeDiet;
    
    //default constrctor
    public Packages(){
    } 
   
    /**
     * Packages is a constructor of class Packages
     * initializing class fields
     * @param name_package as a package name
     * @param duration_package as a package duration
     * @param Price as a package price
     */
    public Packages(String name_package,int duration_package,double Price){
        this.namePackage=name_package;
        this.durationPackage=duration_package;
        this.pricePackage=Price;
    }
    
     //setters

    /**
     * set the namePackage attribute
     * @param name_package name of package
     */
    public void setName(String name_package){
          this.namePackage = name_package; 
         }
    
    /**
     * set the durationPackage attribute
     * @param duration_package duration of package
     */
    public void setDuration(int duration_package) { 
        if(duration_package>0){//muste be month positive integer
        this.durationPackage = duration_package;     
        }
    }

    /**
     * set the pricePackage attribute
     * @param price_package price of package
     */    
    public void setPrice(double price_package) {
        this.pricePackage = price_package;
    }
    
    /**
     * set the typeDiet attribute
     * @param type_diet type of diet
     */
    public void setDiet(Diets type_diet) {
        this.typeDiet =type_diet ;
    }
    
    /**
     * set the workout attribute
     * @param workout workout of listWorkout
     */
    
    public void setWorkout(Workouts workout) {
       listWorkout.add(workout);
    }
    //getters
    
    /**
    * getName instance method that return the name of package 
    * @return String namePackage 
    */
    public String getName() {
        return namePackage;
    }
    
    /**
    * getDuration instance method that return the duration of package 
    * @return int durationPackage 
    */

    public int getDuration() {       
        return durationPackage;
    }
    
    /**
    * getDiet instance method that return the type of diet
    * @return Diets typeDiet 
    */
    public Diets getDiet() {
        return typeDiet;
    }
    
    /**
    * getWorkout instance method that return the list of workout
    * @return Workouts listWorkout 
    */
    
   public ArrayList<Workouts> getWorkout() {
        return listWorkout;
    }
   
   /**
    * priceOfSubscription instance method that return the price of package
    * @return double pricePackage 
    */
     public double priceOfSubscription(){
         return pricePackage;
     }
     
     /**
      *  toString method represent information about objects from class Packages
      * @return string 
      */

    @Override
    public String toString() {
        return "Packages{ Package name: " + namePackage + ", Package duration: " + durationPackage + " month,"+" Package price: " + pricePackage +" SR"+ ",Diet type: " + typeDiet + ", workout: " + listWorkout +'}';
    }
     
}
