/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gymmanagmentsystem_442004697;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

     

/**
 *interface Editor which hava collection of abstract method using it by abstract class Person and class Workout 
 * it provide methods working on the arraylist to manipulate on the data
 * @author Esra hussain saif
 */

import java.util.*;

public interface Editor {
    
    //edite it 
    void add(int index , String objName);//method whitch to add members or name of workout in class Workout 
    void  delete(int index);//method delete an element from the arraylist by its position
    ArrayList<String> getList();
    int search(String obj);//search about specific object and return its position
    
    
}
